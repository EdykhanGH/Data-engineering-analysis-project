-- Products Table
DROP TABLE IF EXISTS products;
CREATE TABLE products (
    id INT PRIMARY KEY,
    title VARCHAR(255),
    description TEXT,
    price FLOAT,
    discountPercentage FLOAT,
    rating FLOAT,
    stock INT,
    brand VARCHAR(255),
    category VARCHAR(255),
    thumbnail VARCHAR(255)
);

-- Staging Products Table
DROP TABLE IF EXISTS staging_products;
CREATE TABLE staging_products (
    id INT PRIMARY KEY,
    title VARCHAR(255),
    description TEXT,
    price FLOAT,
    discountPercentage FLOAT,
    rating FLOAT,
    stock INT,
    brand VARCHAR(255),
    category VARCHAR(255),
    thumbnail VARCHAR(255)
);

-- Users Table
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id INT PRIMARY KEY,
    firstName VARCHAR(100),
    lastName VARCHAR(100),
    maidenName VARCHAR(100),
    age INT,
    gender VARCHAR(10),
    email VARCHAR(255),
    phone VARCHAR(50),
    username VARCHAR(100),
    password VARCHAR(255),
    birthDate DATE,
    image VARCHAR(255),
    address JSONB
);

-- Staging Users Table
DROP TABLE IF EXISTS staging_users;
CREATE TABLE staging_users (
    id INT PRIMARY KEY,
    firstName VARCHAR(100),
    lastName VARCHAR(100),
    maidenName VARCHAR(100),
    age INT,
    gender VARCHAR(10),
    email VARCHAR(255),
    phone VARCHAR(50),
    username VARCHAR(100),
    password VARCHAR(255),
    birthDate DATE,
    image VARCHAR(255),
    address JSONB
);

-- Carts Table
DROP TABLE IF EXISTS carts;
CREATE TABLE carts (
    id INT PRIMARY KEY,
    userId INT,
    products JSONB,
    total FLOAT,
    discountedTotal FLOAT,
    totalProducts INT,
    totalQuantity INT
);

-- Staging Carts Table
DROP TABLE IF EXISTS staging_carts;
CREATE TABLE staging_carts (
    id INT PRIMARY KEY,
    userId INT,
    products JSONB,
    total FLOAT,
    discountedTotal FLOAT,
    totalProducts INT,
    totalQuantity INT
);

-- Comments Table
DROP TABLE IF EXISTS comments;
CREATE TABLE comments (
    id INT PRIMARY KEY,
    postId INT,
    body TEXT,
    username VARCHAR(100),
    userId INT
);

-- Staging Comments Table
DROP TABLE IF EXISTS staging_comments;
CREATE TABLE staging_comments (
    id INT PRIMARY KEY,
    postId INT,
    body TEXT,
    username VARCHAR(100),
    userId INT
);
