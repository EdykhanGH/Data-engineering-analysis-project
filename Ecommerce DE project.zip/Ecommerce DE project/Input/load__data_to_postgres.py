import requests
import pandas as pd
from sqlalchemy import create_engine, text
import json

db_user = "postgres"
db_password = "07012025"
db_host = "localhost"
db_name = "sales_db"

engine = create_engine(f"postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}")

endpoints = {
    "products": "https://dummyjson.com/products",
    "users": "https://dummyjson.com/users",
    "carts": "https://dummyjson.com/carts",
    "comments": "https://dummyjson.com/comments"
}

def fetch_api_data(url):
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Failed to fetch data from {url}")
        return None

def clean_dataframe(df):
    for col in df.columns:
        if df[col].apply(lambda x: isinstance(x, (dict, list))).any():
            df[col] = df[col].apply(lambda x: json.dumps(x) if isinstance(x, (dict, list)) else x)
    return df

def load_data(df, table_name):
    try:
        df = clean_dataframe(df)
        
        df.to_sql(f"{table_name}", engine, if_exists="replace", index=False)
        print(f"Data loaded into {table_name}")
    except Exception as e:
        print(f"Error loading data into {table_name}: {e}")


if __name__ == "__main__":
    for table_name, url in endpoints.items():
        api_data = fetch_api_data(url)

        if api_data:
            records = api_data[list(api_data.keys())[0]]
            df = pd.json_normalize(records)

            load_data(df, table_name)


engine.dispose()
