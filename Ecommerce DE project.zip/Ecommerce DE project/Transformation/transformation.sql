DROP TABLE IF EXISTS transformed_products;
CREATE TABLE transformed_products (
    id INT PRIMARY KEY,
    title VARCHAR(255),
    description TEXT,
    price FLOAT,
    discountPercentage FLOAT,
    discountedPrice FLOAT,
    rating FLOAT,
    stock INT,
    stockStatus VARCHAR(20),
    brand VARCHAR(255),
    category VARCHAR(255),
    thumbnail VARCHAR(255)
);

DROP TABLE IF EXISTS transformed_users;
CREATE TABLE transformed_users (
    id INT PRIMARY KEY,
    firstName VARCHAR(100),
    lastName VARCHAR(100),
    maidenName VARCHAR(100),
    age INT,
    gender VARCHAR(10),
    email VARCHAR(255),
    phone VARCHAR(50),
    username VARCHAR(100),
    password VARCHAR(255),
    birthDate DATE,
    image VARCHAR(255),
    address JSONB,
    ageGroup VARCHAR(20)
);

DROP TABLE IF EXISTS transformed_comments;
CREATE TABLE transformed_comments (
    id INT PRIMARY KEY,
    postId INT,
    body TEXT,
    username VARCHAR(100),
    userId INT,
    sentiment VARCHAR(20)  
);

DROP TABLE IF EXISTS category_sales_analysis;
CREATE TABLE category_sales_analysis (
    category VARCHAR(255),
    totalRevenue FLOAT,
    totalProducts INT,
    averageDiscount FLOAT,
    totalStock INT
);

DROP TABLE IF EXISTS data_quality_checks;
CREATE TABLE data_quality_checks (
    table_name VARCHAR(255),
    record_id INT,
    issue_type VARCHAR(255)  
);
