import pandas as pd
from sqlalchemy import create_engine, text
import numpy as np

db_user = "postgres"
db_password = "07012025"
db_host = "localhost"
db_name = "sales_db"


engine = create_engine(f"postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}")

def transform_products():
    query = "SELECT * FROM products"
    
    with engine.connect() as connection:
        products_df = pd.read_sql(text(query), connection)

    products_df['discountedPrice'] = products_df['price'] * (1 - products_df['discountPercentage'] / 100)
    products_df['stockStatus'] = products_df['stock'].apply(lambda x: 'In Stock' if x > 0 else 'Out of Stock')

    products_df.to_sql('transformed_products', engine, if_exists='replace', index=False)
    print("Transformed products table loaded.")

def transform_users():
    query = "SELECT * FROM users"
    
    with engine.connect() as connection:
        users_df = pd.read_sql(text(query), connection)

    users_df['gender'] = users_df['gender'].apply(lambda x: 'Male' if x in ['M', 'Male'] else 'Female' if x in ['F', 'Female'] else 'Other')
    users_df['ageGroup'] = pd.cut(users_df['age'], bins=[0, 18, 25, 35, 45, 55, 65, np.inf], labels=['<18', '18-24', '25-34', '35-44', '45-54', '55-64', '65+'])
    current_year = pd.Timestamp.now().year
    users_df['tenure_years'] = current_year - pd.to_datetime(users_df['birthDate']).dt.year

    
    users_df.to_sql('transformed_users', engine, if_exists='replace', index=False)
    print("Transformed users table loaded.")

def transform_comments():
    query = "SELECT * FROM comments"
    
    with engine.connect() as connection:
        comments_df = pd.read_sql(text(query), connection)

    comments_df['sentiment'] = comments_df['body'].apply(lambda x: 'Positive' if 'good' in x.lower() or 'great' in x.lower() else 
                                                         'Negative' if 'bad' in x.lower() or 'poor' in x.lower() else 'Neutral')

    comments_df.to_sql('transformed_comments', engine, if_exists='replace', index=False)
    print("Transformed comments table loaded.")

def transform_category_sales():
    query = "SELECT * FROM products"
    
    with engine.connect() as connection:
        products_df = pd.read_sql(text(query), connection)

    category_sales = products_df.groupby('category').agg(
        totalRevenue=('price', 'sum'),
        totalProducts=('id', 'count'),
        averageDiscount=('discountPercentage', 'mean'),
        totalStock=('stock', 'sum')
    ).reset_index()

    category_sales.to_sql('category_sales_analysis', engine, if_exists='replace', index=False)
    print("Category sales analysis table loaded.")

def transform_data_quality_checks():
    data_quality_checks = []

    query = "SELECT id FROM users WHERE email IS NULL OR username IS NULL"
    with engine.connect() as connection:
        missing_data_users = pd.read_sql(text(query), connection)
        for row in missing_data_users.itertuples():
            data_quality_checks.append(('users', row.id, 'Missing Data'))

    query = "SELECT id FROM products GROUP BY id HAVING COUNT(*) > 1"
    with engine.connect() as connection:
        duplicates_products = pd.read_sql(text(query), connection)
        for row in duplicates_products.itertuples():
            data_quality_checks.append(('products', row.id, 'Duplicate'))

    quality_df = pd.DataFrame(data_quality_checks, columns=['table_name', 'record_id', 'issue_type'])
    quality_df.to_sql('data_quality_checks', engine, if_exists='replace', index=False)
    print("Data quality checks table loaded.")

def main():
    transform_products()
    transform_users()
    transform_comments()
    transform_category_sales()
    transform_data_quality_checks()

if __name__ == "__main__":
    main()

engine.dispose()
